select
*
from {{ source('raw', 'EMPLOYEE_DETAILS') }}